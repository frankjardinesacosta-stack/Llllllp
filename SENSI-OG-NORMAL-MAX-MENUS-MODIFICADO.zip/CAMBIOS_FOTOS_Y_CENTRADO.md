# SENSI OG — ajustes de imágenes y menú

- Se reemplazó la imagen roja circular por la fotografía de Dios/crucifix proporcionada, recortada para que el motivo principal se aprecie dentro del círculo.
- Se reemplazó el banner Free Fire MAX × Naruto por la imagen proporcionada.
- Se ajustó el banner para ocupar el botón horizontal sin quedar reducido a una franja estrecha.
- Se redujo el espacio superior del contenido para acercar el menú de Patches al centro de la pantalla.
- Se conservaron los enlaces de Telegram a https://t.me/SENSIOGCUBA y la marca SENSI OG.

No se ha compilado ni probado en un dispositivo iOS.
