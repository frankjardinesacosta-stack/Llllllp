# Cómo subir este proyecto a GitHub sin errores

## Opción recomendada (Git en la terminal)

1. Descomprime este ZIP en una carpeta.
2. En esa carpeta:

```bash
git init
git add .
git commit -m "SENSI OG normal + max menus"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/TU_REPO.git
git push -u origin main
```

## Si usas la web de GitHub

- El ZIP completo (~12 MB) está por debajo del límite de 25 MB del navegador.
- Mejor: crea el repo vacío y sube el **contenido descomprimido**, no el ZIP dentro del repo.
- O crea un **Release** y adjunta el ZIP en Assets.

## Si falla el Action "Generar IPA"

- Entra en la pestaña Actions del repo y abre el job en rojo.
- Copia el log del paso que falló y revísalo.
- El workflow usa `CODE_SIGNING_ALLOWED=NO` (IPA sin firmar).

## Archivos importantes añadidos en esta versión

- Parches Normal: `ThreeOneOSFive/Patches/AIM_HEAD.3105`, `AIM_DRAG.3105`, `Cuello.3105`, `Pecho.3105`
- Incluidos en el target Xcode (`project.pbxproj`)
- Botón "Volver atrás" al selector Free Fire Normal / MAX
- Calculadora con estilo SENSI OG
